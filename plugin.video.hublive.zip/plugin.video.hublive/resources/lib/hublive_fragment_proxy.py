import base64
import json
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse

import requests

from playback_state import load_playback_state


# HLS fragment tuning: modeled on the supplied Streamlink implementation.
OPTIMAL_SEGMENT_THREADS = 4
OPTIMAL_LIVE_EDGE = 6
OPTIMAL_RINGBUFFER_SIZE = 64 * 1024 * 1024
OPTIMAL_SEGMENT_TIMEOUT = 15.0
OPTIMAL_SEGMENT_ATTEMPTS = 4
PREFETCH_SEGMENTS = 12

_PROXY_PREFIX = "/__hublive_proxy__"
_CACHE_LOCK = threading.RLock()
_CACHE = {}
_PLAYLISTS = {}
_PREFETCH_ACTIVE = {}
_PREFETCH_LOCK = threading.RLock()
_SERVER = None
_THREAD = None
_DIRECT_STATES = {}
_DIRECT_STATES_LOCK = threading.RLock()


def _headers():
    return {
        "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
        "Accept": "*/*",
        "Accept-Encoding": "identity",
        "Connection": "keep-alive",
    }


def _state_for(session_id):
    state = load_playback_state()
    if state.get("session_id") != session_id or state.get("kind") != "live":
        return None
    return state


def _fetch(url, timeout=(4, OPTIMAL_SEGMENT_TIMEOUT), stream=False):
    session = requests.Session()
    try:
        from requests.adapters import HTTPAdapter
        from urllib3.util.retry import Retry
        retry = Retry(
            total=OPTIMAL_SEGMENT_ATTEMPTS - 1,
            connect=OPTIMAL_SEGMENT_ATTEMPTS - 1,
            read=OPTIMAL_SEGMENT_ATTEMPTS - 1,
            status=OPTIMAL_SEGMENT_ATTEMPTS - 1,
            backoff_factor=0.20,
            status_forcelist=(408, 429, 500, 502, 503, 504),
            allowed_methods=frozenset(["GET"]),
            raise_on_status=False,
        )
        adapter = HTTPAdapter(pool_connections=16, pool_maxsize=16, max_retries=retry)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
    except Exception:
        pass
    session.headers.update(_headers())
    try:
        response = session.get(url, timeout=timeout, verify=False, allow_redirects=True, stream=stream)
        response.raise_for_status()
        return response
    except Exception:
        session.close()
        raise


def _encode_url(url):
    return base64.urlsafe_b64encode(url.encode("utf-8")).decode("ascii").rstrip("=")


def _decode_url(value):
    value += "=" * (-len(value) % 4)
    return base64.urlsafe_b64decode(value.encode("ascii")).decode("utf-8")


def _cache_get(url):
    with _CACHE_LOCK:
        item = _CACHE.get(url)
        if not item:
            return None
        if item[0] < time.time():
            _CACHE.pop(url, None)
            return None
        return item[1], item[2]


def _cache_put(url, data, content_type, ttl=30):
    with _CACHE_LOCK:
        _CACHE[url] = (time.time() + ttl, data, content_type)
        if len(_CACHE) > 160:
            oldest = sorted(_CACHE.items(), key=lambda kv: kv[1][0])[:48]
            for key, _ in oldest:
                _CACHE.pop(key, None)


def _prefetch(urls, workers):
    def worker(url):
        if _cache_get(url):
            return
        try:
            response = _fetch(url)
            try:
                data = response.content
                content_type = response.headers.get("Content-Type", "application/octet-stream")
            finally:
                response.close()
            _cache_put(url, data, content_type, ttl=60)
        except Exception:
            pass

    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="HubLiveSeg") as pool:
        list(pool.map(worker, urls))

def _background_prefetch(urls, workers=OPTIMAL_SEGMENT_THREADS):
    """Keep a rolling cushion of future HLS segments ready before Kodi asks for them."""
    unique = []
    seen = set()
    for url in urls:
        if url and url not in seen and not _cache_get(url):
            seen.add(url)
            unique.append(url)
    if not unique:
        return
    key = tuple(unique)
    with _PREFETCH_LOCK:
        if key in _PREFETCH_ACTIVE:
            return
        _PREFETCH_ACTIVE[key] = time.time()
    def run():
        try:
            _prefetch(unique, max(1, min(int(workers), OPTIMAL_SEGMENT_THREADS)))
        finally:
            with _PREFETCH_LOCK:
                _PREFETCH_ACTIVE.pop(key, None)
    threading.Thread(target=run, name="HubLiveBuffer", daemon=True).start()


def _rewrite_playlist(text, session_id, playlist_url, delay_segments=OPTIMAL_LIVE_EDGE):
    """Rewrite an HLS live playlist and intentionally stay a few segments behind live.

    Keeping the newest N segments out of Kodi's playlist creates a stable playback
    cushion. We only apply the delay when the upstream playlist has enough segments;
    otherwise we serve the available window rather than returning an empty playlist.
    """
    lines = text.splitlines()
    # A media segment is a non-comment URI line. Keep the complete line structure
    # for tags, but omit the newest N media-segment URI lines from the playback view.
    media_positions = []
    for pos, line in enumerate(lines):
        stripped = line.strip()
        if stripped and not stripped.startswith("#"):
            media_positions.append(pos)

    delay_segments = max(0, int(delay_segments or 0))
    keep_count = len(media_positions) - delay_segments
    if keep_count <= 0:
        # Very short live windows cannot sustain the requested delay yet.
        keep_positions = set(media_positions)
    else:
        keep_positions = set(media_positions[:keep_count])

    segment_urls = []
    rewritten = []
    for pos, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            rewritten.append(line)
            continue

        # Rewrite URI="..." attributes, including AES-128 key URIs.
        def repl(match):
            raw = match.group(2)
            absolute = urljoin(playlist_url, raw)
            return match.group(1) + _proxy_url(session_id, absolute) + match.group(3)

        line2 = re.sub(r'(URI=["\'])([^"\']+)(["\'])', repl, line, flags=re.I)
        if not stripped.startswith("#"):
            if pos not in keep_positions:
                continue
            absolute = urljoin(playlist_url, stripped)
            segment_urls.append(absolute)
            line2 = _proxy_url(session_id, absolute)
        rewritten.append(line2)

    with _CACHE_LOCK:
        _PLAYLISTS[session_id] = {"urls": segment_urls, "updated": time.time()}
    return "\n".join(rewritten) + "\n"

def _proxy_url(session_id, upstream_url):
    return f"{_PROXY_PREFIX}/segment/{quote(session_id, safe='')}/{_encode_url(upstream_url)}"


_DIRECT_CHUNK_SIZE = 1024 * 1024
_DIRECT_READ_TIMEOUT = (4, 20)
_DIRECT_STARTUP_DELAY = 5.0


def _range_probe(url):
    """Check whether the upstream live endpoint honors byte ranges."""
    try:
        response = requests.get(
            url,
            headers=dict(_headers(), Range="bytes=0-0"),
            timeout=(4, 8),
            verify=False,
            allow_redirects=True,
            stream=True,
        )
        try:
            content_range = response.headers.get("Content-Range", "")
            return response.status_code == 206 and content_range.startswith("bytes 0-0/")
        finally:
            response.close()
    except Exception:
        return False


def _stream_direct_single(handler, url):
    """Stream direct MPEG-TS with a startup cushion instead of playing at live edge."""
    import queue

    response = requests.get(
        url,
        headers=_headers(),
        timeout=_DIRECT_READ_TIMEOUT,
        verify=False,
        allow_redirects=True,
        stream=True,
    )
    response.raise_for_status()
    content_type = response.headers.get("Content-Type", "video/mp2t")
    handler.send_response(200)
    handler.send_header("Content-Type", content_type)
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Connection", "close")
    handler.end_headers()

    q = queue.Queue(maxsize=128)
    done = threading.Event()
    first_data = [None]

    def reader():
        try:
            for chunk in response.iter_content(chunk_size=256 * 1024):
                if not chunk:
                    continue
                if first_data[0] is None:
                    first_data[0] = time.monotonic()
                q.put(chunk)
        except Exception:
            pass
        finally:
            done.set()
            try:
                q.put_nowait(None)
            except Exception:
                pass

    thread = threading.Thread(target=reader, name="HubLiveTSBuffer", daemon=True)
    thread.start()
    try:
        # Build an intentional 15-second live delay before sending anything to Kodi.
        deadline = None
        while first_data[0] is None and not done.is_set():
            time.sleep(0.05)
        if first_data[0] is not None:
            deadline = first_data[0] + _DIRECT_STARTUP_DELAY
        while deadline is not None and time.monotonic() < deadline:
            if done.is_set() and q.empty():
                break
            time.sleep(0.05)

        while True:
            chunk = q.get()
            if chunk is None:
                break
            handler.wfile.write(chunk)
            handler.wfile.flush()
    finally:
        response.close()

def _stream_direct_four_threads(handler, url):
    """Download a growing live object through four concurrent byte-range workers.

    Workers always fetch disjoint ranges and the handler emits them in order.
    This only activates when the origin explicitly supports HTTP 206 ranges.
    """
    import queue

    out = queue.Queue(maxsize=8)
    stop = threading.Event()
    next_lock = threading.Lock()
    next_index = [0]

    def worker():
        session = requests.Session()
        session.headers.update(_headers())
        try:
            while not stop.is_set():
                with next_lock:
                    idx = next_index[0]
                    next_index[0] += 1
                start = idx * _DIRECT_CHUNK_SIZE
                end = start + _DIRECT_CHUNK_SIZE - 1
                try:
                    response = session.get(
                        url,
                        headers={**_headers(), "Range": f"bytes={start}-{end}"},
                        timeout=_DIRECT_READ_TIMEOUT,
                        verify=False,
                        allow_redirects=True,
                    )
                    if response.status_code != 206:
                        response.close()
                        stop.set()
                        out.put((idx, None, "range-not-supported"))
                        return
                    data = response.content
                    response.close()
                    if not data:
                        # A live source may not have reached this range yet.
                        with next_lock:
                            next_index[0] = min(next_index[0], idx)
                        time.sleep(0.15)
                        continue
                    out.put((idx, data, None))
                except Exception as exc:
                    if stop.is_set():
                        return
                    out.put((idx, None, str(exc)))
                    stop.set()
                    return
        finally:
            session.close()

    workers = [threading.Thread(target=worker, name=f"HubLiveTS{i+1}", daemon=True) for i in range(4)]
    for thread in workers:
        thread.start()

    pending = {}
    expected = 0
    try:
        while not stop.is_set():
            idx, data, error = out.get()
            if error:
                if error == "range-not-supported":
                    # This should only happen if the origin changed behavior mid-stream.
                    return False
                raise IOError(error)
            pending[idx] = data
            while expected in pending:
                data = pending.pop(expected)
                handler.wfile.write(data)
                handler.wfile.flush()
                expected += 1
                if len(data) < _DIRECT_CHUNK_SIZE:
                    # End-of-current-file. For a live source, keep requesting the next range.
                    pass
        return True
    finally:
        stop.set()



class _Handler(BaseHTTPRequestHandler):
    server_version = "HubLiveFragmentProxy/1.0"

    def log_message(self, fmt, *args):
        return

    def _send(self, code, content_type, body, extra=None):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/__hublive_proxy__/health":
            self._send(200, "text/plain", b"ok")
            return

        prefix = "/__hublive_proxy__/playlist/"
        if path.startswith(prefix) and path.endswith(".m3u8"):
            session_id = path[len(prefix):-5]
            state = _state_for(session_id)
            if not state:
                self._send(404, "text/plain", b"session not found")
                return
            upstream = state.get("resolved_url") or ""
            try:
                response = _fetch(upstream)
                try:
                    body = response.content
                    content_type = response.headers.get("Content-Type", "application/vnd.apple.mpegurl")
                    text = body.decode("utf-8", "replace")
                    rewritten = _rewrite_playlist(text, session_id, response.url or upstream, delay_segments=OPTIMAL_LIVE_EDGE).encode("utf-8")
                finally:
                    response.close()
                self._send(200, content_type, rewritten)
            except Exception as exc:
                self._send(502, "text/plain", ("playlist error: " + str(exc)).encode("utf-8"))
            return

        prefix = "/__hublive_proxy__/segment/"
        if path.startswith(prefix):
            rest = path[len(prefix):]
            parts = rest.split("/", 1)
            if len(parts) != 2:
                self._send(400, "text/plain", b"bad segment path")
                return
            session_id, encoded = parts
            state = _state_for(session_id)
            if not state:
                self._send(404, "text/plain", b"session not found")
                return
            try:
                upstream = _decode_url(unquote(encoded))
            except Exception:
                self._send(400, "text/plain", b"bad url")
                return

            with _CACHE_LOCK:
                playlist = _PLAYLISTS.get(session_id, {}).get("urls", [])
            try:
                index = playlist.index(upstream)
            except ValueError:
                index = -1
            if index >= 0:
                # Keep a cushion of 12 segments ahead. Four workers fill it in parallel.
                next_urls = playlist[index:index + PREFETCH_SEGMENTS]
            else:
                next_urls = [upstream]

            workers = OPTIMAL_SEGMENT_THREADS
            _background_prefetch(next_urls, workers)
            # If Kodi arrived before the background buffer finished, synchronously fill
            # the requested segment so playback does not see an empty cache.
            if not _cache_get(upstream):
                _prefetch([upstream], workers=1)
            cached = _cache_get(upstream)
            if not cached:
                self._send(502, "text/plain", b"segment download failed")
                return
            body, content_type = cached
            self._send(200, content_type, body)
            return

        prefix = "/__hublive_proxy__/stream/"
        if path.startswith(prefix):
            session_id = path[len(prefix):]
            state = _state_for(session_id)
            if not state:
                self._send(404, "text/plain", b"session not found")
                return
            upstream = state.get("resolved_url") or ""
            if not upstream:
                self._send(404, "text/plain", b"missing upstream")
                return

            try:
                # First determine whether this live endpoint is actually an HLS
                # playlist.  A number of providers use /play/live.php?extension=ts
                # but return an m3u8 body after authentication/redirects.  In that
                # case we MUST expose a local playlist to Kodi; otherwise Kodi reads
                # the stream as one endless TS connection and the segment buffer is
                # never used.
                looks_hls = ".m3u8" in (urlparse(upstream).path or "").lower()
                if looks_hls or "m3u8" in (urlparse(upstream).query or "").lower():
                    response = _fetch(upstream)
                    try:
                        body = response.content
                        ctype = response.headers.get("Content-Type", "")
                        text = body.decode("utf-8", "replace")
                        if "#EXTM3U" in text:
                            rewritten = _rewrite_playlist(
                                text, session_id, response.url or upstream, delay_segments=OPTIMAL_LIVE_EDGE
                            ).encode("utf-8")
                            # Start filling the 12-segment cushion immediately,
                            # before Kodi asks for the first segment.
                            with _CACHE_LOCK:
                                first_segments = list(_PLAYLISTS.get(session_id, {}).get("urls", []))[:PREFETCH_SEGMENTS]
                            if first_segments:
                                _background_prefetch(first_segments, workers=4)
                            self._send(200, "application/vnd.apple.mpegurl", rewritten, {
                                "Cache-Control": "no-cache, no-store, must-revalidate",
                                "Pragma": "no-cache",
                            })
                            return
                    finally:
                        response.close()

                # Direct MPEG-TS is not a segmented object. Four arbitrary byte
                # ranges are unsafe for a growing live file, so only use the range
                # worker when the origin demonstrably supports it. Otherwise keep
                # one continuous connection rather than corrupting the stream.
                # A continuous MPEG-TS live stream cannot safely be split into
                # arbitrary byte ranges. Probing with Range also creates an extra
                # connection at startup, which can make some IPTV origins reject
                # the following playback request. Prefer one stable connection and
                # build a small startup cushion in memory instead.
                _stream_direct_single(self, upstream)
            except Exception as exc:
                try:
                    self._send(502, "text/plain", ("stream error: " + str(exc)).encode("utf-8"))
                except Exception:
                    pass
            return

        self._send(404, "text/plain", b"not found")


def start_proxy(port=47821):
    global _SERVER, _THREAD
    if _SERVER is not None:
        return True
    try:
        _SERVER = ThreadingHTTPServer(("127.0.0.1", int(port)), _Handler)
        _THREAD = threading.Thread(target=_SERVER.serve_forever, name="HubLiveHLSProxy", daemon=True)
        _THREAD.start()
        return True
    except Exception:
        _SERVER = None
        _THREAD = None
        return False


def stop_proxy():
    global _SERVER, _THREAD
    server = _SERVER
    _SERVER = None
    _THREAD = None
    if server:
        try:
            server.shutdown()
            server.server_close()
        except Exception:
            pass
